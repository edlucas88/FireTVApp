# puffer-firetv-example
Stanford Puffer Live TV Streaming App for Fire TV (Example / How-to)

## gh-pages branch

If you're forking this repository, you'll want to edit the `gh-pages` branch **(this branch)** and replace the session details at the bottom of `index.html` with your own.

You can watch this video to see exactly how it's done: 
https://www.loom.com/share/24f6ecd0c9484e2fb6878d4bd8a6c8db

## Publishing

Once you publish your `gh-pages` branch, your final url will be something like this:

https://kidgodzilla.github.io/puffer-firetv-example/

(with the username being your own).
